<?php

define('DB_USER', "iottechn_admin	");     // Your database user name
define('DB_PASSWORD', "admin1@");			// Your database password (mention your db password here)
define('DB_DATABASE', "iottechn_demo"); // Your database name
define('DB_SERVER', "mysql06.dotvndns.vn");			// db server (Mostly will be 'local' host)

?>
